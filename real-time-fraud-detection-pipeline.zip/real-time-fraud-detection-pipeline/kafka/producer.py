"""
Simulates transaction events and publishes them to Kafka.

This file is intentionally written in a readable, human style instead of
over-abstracting everything. The goal is to make the GitHub repo look like
something an actual engineer would maintain for a portfolio project.
"""

import json
import os
import random
import time
from datetime import datetime, timezone
from uuid import uuid4

from confluent_kafka import Producer
from dotenv import load_dotenv
from faker import Faker

load_dotenv()

fake = Faker()

BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "transactions")

producer_config = {
    "bootstrap.servers": BOOTSTRAP_SERVERS,
    "client.id": "fraud-producer-local",
}

producer = Producer(producer_config)

merchant_categories = [
    "grocery",
    "electronics",
    "travel",
    "gaming",
    "fuel",
    "restaurant",
    "subscription",
]

countries = ["US", "CA", "IN", "GB", "DE", "SG"]


def delivery_report(err, msg) -> None:
    if err is not None:
        print(f"[ERROR] Delivery failed: {err}")
    else:
        print(
            f"[INFO] Sent event to topic={msg.topic()} "
            f"partition={msg.partition()} offset={msg.offset()}"
        )


def generate_transaction() -> dict:
    amount = round(random.uniform(5, 5000), 2)
    card_present = random.choice([True, False])

    # Simple fraud simulation logic:
    # - high value cross-border
    # - late-night digital transaction
    # - repeated foreign spend
    is_cross_border = random.random() < 0.15
    transaction_country = random.choice(countries)
    home_country = "US"
    event_hour = random.randint(0, 23)

    return {
        "transaction_id": str(uuid4()),
        "customer_id": random.randint(10000, 99999),
        "merchant_id": random.randint(1000, 9999),
        "merchant_category": random.choice(merchant_categories),
        "amount": amount,
        "currency": "USD",
        "country": transaction_country,
        "customer_home_country": home_country,
        "event_ts": datetime.now(timezone.utc).isoformat(),
        "card_present": card_present,
        "channel": random.choice(["swipe", "chip", "tap", "online"]),
        "device_id": fake.uuid4(),
        "ip_address": fake.ipv4_public(),
        "event_hour": event_hour,
        "risk_signal": int(
            (amount > 2500 and is_cross_border)
            or (not card_present and amount > 1800 and event_hour in [0, 1, 2, 3, 4])
            or (transaction_country != home_country and amount > 1200)
        ),
    }


def main() -> None:
    print(f"[INFO] Starting Kafka producer on {BOOTSTRAP_SERVERS} -> topic '{TOPIC}'")
    try:
        while True:
            event = generate_transaction()
            producer.produce(
                TOPIC,
                key=event["transaction_id"],
                value=json.dumps(event),
                callback=delivery_report,
            )
            producer.poll(0)
            time.sleep(0.20)  # ~5 events/sec for local demo
    except KeyboardInterrupt:
        print("\n[INFO] Stopping producer...")
    finally:
        producer.flush()


if __name__ == "__main__":
    main()
