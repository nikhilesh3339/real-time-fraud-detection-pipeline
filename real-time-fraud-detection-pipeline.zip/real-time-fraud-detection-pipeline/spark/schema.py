from pyspark.sql.types import BooleanType, DoubleType, IntegerType, StringType, StructField, StructType

transaction_schema = StructType([
    StructField("transaction_id", StringType(), False),
    StructField("customer_id", IntegerType(), True),
    StructField("merchant_id", IntegerType(), True),
    StructField("merchant_category", StringType(), True),
    StructField("amount", DoubleType(), True),
    StructField("currency", StringType(), True),
    StructField("country", StringType(), True),
    StructField("customer_home_country", StringType(), True),
    StructField("event_ts", StringType(), True),
    StructField("card_present", BooleanType(), True),
    StructField("channel", StringType(), True),
    StructField("device_id", StringType(), True),
    StructField("ip_address", StringType(), True),
    StructField("event_hour", IntegerType(), True),
    StructField("risk_signal", IntegerType(), True),
])
