"""
Spark Structured Streaming job that reads transaction events from Kafka,
applies a readable rule-based fraud classification, and loads curated
micro-batches into Snowflake.

For portfolio use, this is easier to explain in interviews than trying to
pretend a hidden ML model is making fraud decisions.
"""

import os

from dotenv import load_dotenv
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr, from_json, to_timestamp, when
from snowflake import connector

from schema import transaction_schema

load_dotenv()

KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "transactions")

SNOWFLAKE_ACCOUNT = os.getenv("SNOWFLAKE_ACCOUNT")
SNOWFLAKE_USER = os.getenv("SNOWFLAKE_USER")
SNOWFLAKE_PASSWORD = os.getenv("SNOWFLAKE_PASSWORD")
SNOWFLAKE_WAREHOUSE = os.getenv("SNOWFLAKE_WAREHOUSE")
SNOWFLAKE_DATABASE = os.getenv("SNOWFLAKE_DATABASE", "FRAUD_DB")
SNOWFLAKE_SCHEMA = os.getenv("SNOWFLAKE_SCHEMA", "PUBLIC")
SNOWFLAKE_ROLE = os.getenv("SNOWFLAKE_ROLE")


def get_spark_session() -> SparkSession:
    return (
        SparkSession.builder
        .appName("RealTimeFraudDetection")
        .config("spark.sql.shuffle.partitions", "4")
        .getOrCreate()
    )


def get_snowflake_connection():
    return connector.connect(
        account=SNOWFLAKE_ACCOUNT,
        user=SNOWFLAKE_USER,
        password=SNOWFLAKE_PASSWORD,
        warehouse=SNOWFLAKE_WAREHOUSE,
        database=SNOWFLAKE_DATABASE,
        schema=SNOWFLAKE_SCHEMA,
        role=SNOWFLAKE_ROLE,
    )


def write_batch_to_snowflake(batch_df, batch_id: int) -> None:
    """
    Writes each micro-batch into Snowflake.
    This is intentionally straightforward for a portfolio project.
    """
    print(f"[INFO] Writing batch_id={batch_id} to Snowflake")
    rows = batch_df.toPandas()

    if rows.empty:
        print("[INFO] Batch was empty; skipping write.")
        return

    conn = get_snowflake_connection()
    cur = conn.cursor()

    try:
        insert_sql = f"""
            INSERT INTO {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.CURATED_TRANSACTIONS (
                transaction_id,
                customer_id,
                merchant_id,
                merchant_category,
                amount,
                currency,
                country,
                customer_home_country,
                event_ts,
                card_present,
                channel,
                device_id,
                ip_address,
                event_hour,
                risk_signal,
                fraud_label,
                fraud_reason
            )
            SELECT
                %(transaction_id)s,
                %(customer_id)s,
                %(merchant_id)s,
                %(merchant_category)s,
                %(amount)s,
                %(currency)s,
                %(country)s,
                %(customer_home_country)s,
                %(event_ts)s,
                %(card_present)s,
                %(channel)s,
                %(device_id)s,
                %(ip_address)s,
                %(event_hour)s,
                %(risk_signal)s,
                %(fraud_label)s,
                %(fraud_reason)s
            WHERE NOT EXISTS (
                SELECT 1
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.CURATED_TRANSACTIONS t
                WHERE t.transaction_id = %(transaction_id)s
            )
        """

        for row in rows.to_dict(orient="records"):
            cur.execute(insert_sql, row)

        conn.commit()
        print(f"[INFO] Loaded {len(rows)} rows into Snowflake.")
    finally:
        cur.close()
        conn.close()


def main() -> None:
    spark = get_spark_session()
    spark.sparkContext.setLogLevel("WARN")

    raw_stream = (
        spark.readStream
        .format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVERS)
        .option("subscribe", KAFKA_TOPIC)
        .option("startingOffsets", "latest")
        .load()
    )

    parsed_stream = (
        raw_stream.selectExpr("CAST(value AS STRING) AS json_str")
        .select(from_json(col("json_str"), transaction_schema).alias("data"))
        .select("data.*")
        .withColumn("event_ts", to_timestamp("event_ts"))
    )

    enriched_stream = (
        parsed_stream
        .withColumn(
            "fraud_label",
            when(
                (col("risk_signal") == 1) | (col("amount") > 3000),
                expr("'fraud_suspected'")
            ).otherwise(expr("'normal'"))
        )
        .withColumn(
            "fraud_reason",
            when(
                (col("risk_signal") == 1) & (col("amount") > 3000),
                expr("'combined_risk_signal_and_high_amount'")
            )
            .when(col("risk_signal") == 1, expr("'risk_signal_triggered'"))
            .when(col("amount") > 3000, expr("'high_amount'"))
            .otherwise(expr("'none'"))
        )
    )

    query = (
        enriched_stream.writeStream
        .outputMode("append")
        .option("checkpointLocation", "./checkpoints/fraud_pipeline")
        .foreachBatch(write_batch_to_snowflake)
        .start()
    )

    print("[INFO] Spark streaming job started.")
    query.awaitTermination()


if __name__ == "__main__":
    main()
