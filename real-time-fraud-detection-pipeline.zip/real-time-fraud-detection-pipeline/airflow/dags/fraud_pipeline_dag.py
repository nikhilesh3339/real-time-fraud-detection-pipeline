from datetime import datetime

from airflow import DAG
from airflow.operators.bash import BashOperator

default_args = {
    "owner": "nikhilesh",
    "depends_on_past": False,
    "retries": 1,
}

with DAG(
    dag_id="fraud_pipeline_local",
    default_args=default_args,
    description="Runs dbt models and tests for the fraud detection pipeline",
    start_date=datetime(2025, 1, 1),
    schedule="@hourly",
    catchup=False,
    tags=["fraud", "streaming", "dbt", "snowflake"],
) as dag:

    dbt_debug = BashOperator(
        task_id="dbt_debug",
        bash_command="cd /opt/airflow/dbt/fraud_dbt && dbt debug --profiles-dir .",
    )

    dbt_run = BashOperator(
        task_id="dbt_run",
        bash_command="cd /opt/airflow/dbt/fraud_dbt && dbt run --profiles-dir .",
    )

    dbt_test = BashOperator(
        task_id="dbt_test",
        bash_command="cd /opt/airflow/dbt/fraud_dbt && dbt test --profiles-dir .",
    )

    dbt_debug >> dbt_run >> dbt_test
