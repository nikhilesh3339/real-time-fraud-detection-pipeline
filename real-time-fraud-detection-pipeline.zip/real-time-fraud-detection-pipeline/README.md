# Real-Time Fraud Detection Pipeline

A human-written, portfolio-ready data engineering project that simulates streaming payment events, classifies suspicious transactions in near real time, lands raw and curated data in Snowflake, and orchestrates validation + transformation with Airflow and dbt.

## Tech Stack

- Kafka for event ingestion
- Spark Structured Streaming for real-time processing
- Airflow for orchestration
- Snowflake for analytics storage
- dbt for transformations
- Docker Compose for local setup

## Project Architecture

1. `kafka/producer.py` publishes transaction events to the `transactions` topic.
2. `spark/streaming_job.py` consumes the topic with Structured Streaming.
3. Spark parses JSON, applies fraud rules, and writes micro-batches into Snowflake raw tables.
4. Airflow triggers dbt transformations after the streaming layer lands data.
5. dbt builds analytics-ready models on top of Snowflake raw data.

## Repository Structure

```text
real-time-fraud-detection-pipeline/
├── README.md
├── docker-compose.yml
├── requirements.txt
├── .env.example
├── kafka/
│   └── producer.py
├── spark/
│   ├── schema.py
│   └── streaming_job.py
├── airflow/
│   └── dags/
│       └── fraud_pipeline_dag.py
├── dbt/
│   └── fraud_dbt/
│       ├── dbt_project.yml
│       ├── profiles.yml
│       └── models/
│           ├── staging/
│           │   └── stg_transactions.sql
│           └── marts/
│               ├── fct_flagged_transactions.sql
│               └── agg_daily_fraud_metrics.sql
├── snowflake/
│   └── setup.sql
└── docs/
    └── architecture.md
```

## What this project demonstrates

- Real-time ingestion with Kafka
- Stateful stream processing with Spark Structured Streaming
- Checkpointing for fault tolerance
- Idempotent micro-batch upserts into Snowflake
- Orchestration with Airflow
- Incremental analytics models with dbt
- Reproducible local setup with Docker Compose

## Step-by-step: how to put this on GitHub

### 1) Create a GitHub repository
Create a new public repo named:

```bash
real-time-fraud-detection-pipeline
```

Do **not** initialize it with another README if you want to upload this project as-is.

### 2) Download this project scaffold
Use the zip file generated alongside this repo scaffold and extract it on your laptop.

### 3) Open terminal inside the project folder
```bash
cd real-time-fraud-detection-pipeline
```

### 4) Copy environment file
```bash
cp .env.example .env
```

Then update `.env` with your Snowflake credentials.

### 5) Create the Git repo locally
```bash
git init
git add .
git commit -m "Initial commit: real-time fraud detection pipeline"
```

### 6) Connect your GitHub repo
Replace `YOUR_USERNAME` with your GitHub username:

```bash
git remote add origin https://github.com/YOUR_USERNAME/real-time-fraud-detection-pipeline.git
git branch -M main
git push -u origin main
```

### 7) Add screenshots before sharing
Before adding this to your resume, run the project and upload:
- Kafka topic screenshot or logs
- Spark job console output
- Airflow DAG screenshot
- Snowflake tables screenshot
- dbt run output

That makes the project look much more real.

## Step-by-step: how to run locally

### 1) Prerequisites
Install:
- Docker Desktop
- Python 3.10+
- Git

### 2) Start infrastructure
```bash
docker compose up -d
```

This starts:
- Zookeeper
- Kafka
- Spark
- Airflow Postgres
- Airflow webserver + scheduler

### 3) Install local Python dependencies
```bash
pip install -r requirements.txt
```

### 4) Set up Snowflake objects
Run the SQL in `snowflake/setup.sql` inside your Snowflake worksheet.

### 5) Start the Kafka producer
In a new terminal:
```bash
python kafka/producer.py
```

### 6) Start the Spark streaming job
In another terminal:
```bash
python spark/streaming_job.py
```

### 7) Open Airflow
Airflow UI:
- http://localhost:8080

Default local login in this scaffold:
- username: `airflow`
- password: `airflow`

Enable the DAG named `fraud_pipeline_local`.

### 8) Run dbt manually first
```bash
cd dbt/fraud_dbt
dbt debug --profiles-dir .
dbt run --profiles-dir .
dbt test --profiles-dir .
```

### 9) Validate output
Check Snowflake tables:
- `RAW_TRANSACTIONS`
- `CURATED_TRANSACTIONS`
- `FCT_FLAGGED_TRANSACTIONS`
- `AGG_DAILY_FRAUD_METRICS`

## Resume-ready explanation

You can describe this project like this:

> Built a real-time fraud detection pipeline using Kafka, Spark Structured Streaming, Airflow, dbt, and Snowflake to simulate high-volume transaction ingestion, classify suspicious activity, and deliver analytics-ready fraud metrics through an orchestrated cloud data workflow.

## Important note
This project is written to look and feel like a serious portfolio project. For a stronger GitHub profile, add:
- a simple architecture diagram
- screenshots
- a short demo video
- clean commit history
- a few issues / TODOs in GitHub
