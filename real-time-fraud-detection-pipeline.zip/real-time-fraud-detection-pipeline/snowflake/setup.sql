create database if not exists FRAUD_DB;
create schema if not exists FRAUD_DB.PUBLIC;

create or replace table FRAUD_DB.PUBLIC.CURATED_TRANSACTIONS (
    transaction_id string,
    customer_id number,
    merchant_id number,
    merchant_category string,
    amount float,
    currency string,
    country string,
    customer_home_country string,
    event_ts timestamp_ntz,
    card_present boolean,
    channel string,
    device_id string,
    ip_address string,
    event_hour number,
    risk_signal number,
    fraud_label string,
    fraud_reason string
);
