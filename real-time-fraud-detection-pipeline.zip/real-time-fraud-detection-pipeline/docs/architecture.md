# Architecture Notes

This project is intentionally designed as a realistic portfolio project rather than an overcomplicated enterprise clone.

## Data flow

Producer -> Kafka topic -> Spark Structured Streaming -> Snowflake curated table -> dbt models -> Airflow orchestration

## Why this design works well for GitHub

- Easy for recruiters to understand
- Easy to demo in an interview
- Easy to explain each layer clearly
- Strong enough to show streaming + orchestration + warehouse + transformation skills

## Interview explanation

You can explain the pipeline like this:

"I used Kafka to simulate transaction traffic, Spark Structured Streaming to process events in micro-batches, and a rule-based fraud classifier to label risky transactions. I wrote curated records into Snowflake and used dbt to model fraud-ready datasets for reporting. Airflow orchestrated dbt runs and tests on top of the streaming output."
