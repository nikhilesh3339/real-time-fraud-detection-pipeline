select
    transaction_id,
    customer_id,
    merchant_id,
    merchant_category,
    amount,
    currency,
    country,
    customer_home_country,
    event_ts,
    channel,
    fraud_label,
    fraud_reason
from {{ ref('stg_transactions') }}
where fraud_label = 'fraud_suspected'
