select
    cast(event_ts as date) as event_date,
    count(*) as total_transactions,
    sum(case when fraud_label = 'fraud_suspected' then 1 else 0 end) as suspected_fraud_transactions,
    round(
        100.0 * sum(case when fraud_label = 'fraud_suspected' then 1 else 0 end) / nullif(count(*), 0),
        2
    ) as suspected_fraud_rate_pct,
    sum(amount) as total_amount_processed,
    sum(case when fraud_label = 'fraud_suspected' then amount else 0 end) as suspected_fraud_amount
from {{ ref('stg_transactions') }}
group by 1
order by 1 desc
